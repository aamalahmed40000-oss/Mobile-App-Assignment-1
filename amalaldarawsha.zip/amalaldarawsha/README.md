# AuthTabApp — Android Assignment

## Project Overview
A two-activity Android app demonstrating:
- Secure form validation with TextWatchers
- Custom back-press / double-back-to-exit logic (Snackbar)
- ViewPager2 + TabLayout with swipeable fragments
- PopupMenu for Light / Night / System mode switching
- Ancestral Up navigation from ModeActivity → MainActivity

---

## Project Structure
```
AuthTabApp/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/example/authtabapp/
│   │   │   ├── MainActivity.java        ← Login screen
│   │   │   ├── ModeActivity.java        ← Tabs screen
│   │   │   ├── TabPagerAdapter.java     ← ViewPager2 adapter
│   │   │   └── TabFragment.java         ← Reusable tab fragment
│   │   └── res/
│   │       ├── layout/
│   │       │   ├── activity_main.xml
│   │       │   ├── activity_mode.xml
│   │       │   └── fragment_tab.xml
│   │       ├── menu/
│   │       │   └── menu_mode.xml
│   │       └── values/
│   │           ├── strings.xml
│   │           ├── colors.xml
│   │           └── themes.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## How to Open in Android Studio
1. Launch **Android Studio**.
2. Choose **File → Open** and select the `AuthTabApp` folder.
3. Wait for Gradle sync to complete.
4. Run on an emulator or physical device (minSdk 24 / Android 7.0+).

---

## Requirements Checklist

### Requirement 1 — MainActivity (Login)
| Feature | Implementation |
|---|---|
| Email EditText | `TextInputEditText` inside `TextInputLayout` (outlined) |
| Password EditText | `TextInputEditText` with password toggle |
| Login Button disabled by default | `android:enabled="false"` |
| TextWatcher validation | Email checked via `Patterns.EMAIL_ADDRESS`; password ≥ 6 chars |
| Double-back-to-exit | `backPressedOnce` flag + Snackbar + 2-second reset `postDelayed` |
| Navigate to ModeActivity | `startActivity(new Intent(..., ModeActivity.class))` |

### Requirement 2 — ModeActivity (Tabs)
| Feature | Implementation |
|---|---|
| ViewPager2 | `androidx.viewpager2.widget.ViewPager2` |
| TabLayout | `com.google.android.material.tabs.TabLayout` via `TabLayoutMediator` |
| 3 tabs: First / Second / Third | `TabPagerAdapter` returns `TabFragment.newInstance(...)` |
| Back on 2nd/3rd tab → First tab | `onBackPressed()` checks `viewPager2.getCurrentItem()` |
| Back on First tab → MainActivity | `super.onBackPressed()` |
| PopupMenu (Light/Night/System) | `AppCompatDelegate.setDefaultNightMode(...)` |
| Up Button (ActionBar ←) | `setDisplayHomeAsUpEnabled(true)` + `onOptionsItemSelected` → `Intent(FLAG_ACTIVITY_CLEAR_TOP)` |

---

## Demo Script (≤ 2 minutes)
1. State full name and student ID.
2. Open app — show Login button is **disabled**.
3. Type invalid email → button stays disabled.
4. Type valid email + 5-char password → still disabled.
5. Add 6th character → button **enables**.
6. Tap **Login** → ModeActivity opens.
7. Swipe through all three tabs.
8. Go to Third tab → press Back → jumps to First tab.
9. Press Back again → returns to MainActivity.
10. Press Back → Snackbar "Press back again to exit" appears.
11. Press Back a second time → app closes.
12. Re-open, login, tap **Set Mode** → show Light/Night/System menu.
