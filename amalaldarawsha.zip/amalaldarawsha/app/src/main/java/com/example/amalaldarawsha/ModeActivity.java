package com.example.amalaldarawsha;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class ModeActivity extends AppCompatActivity {

    private ViewPager2 viewPager2;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);

        // Enable the Up (back arrow) button in the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Mode Activity");
        }

        viewPager2 = findViewById(R.id.viewPager2);
        tabLayout  = findViewById(R.id.tabLayout);

        // Set up the ViewPager2 adapter with 3 fragments
        TabPagerAdapter adapter = new TabPagerAdapter(this);
        viewPager2.setAdapter(adapter);

        // Bind TabLayout to ViewPager2
        new TabLayoutMediator(tabLayout, viewPager2, (tab, position) -> {
            switch (position) {
                case 0: tab.setText("First");  break;
                case 1: tab.setText("Second"); break;
                case 2: tab.setText("Third");  break;
            }
        }).attach();

        // "Set Mode" button with PopupMenu
        Button btnSetMode = findViewById(R.id.btnSetMode);
        btnSetMode.setOnClickListener(v -> showModePopupMenu(v));
    }

    private void showModePopupMenu(View anchor) {
        PopupMenu popupMenu = new PopupMenu(this, anchor);
        popupMenu.getMenuInflater().inflate(R.menu.menu_mode, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menuLight) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                Toast.makeText(this, "Light mode selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.menuNight) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                Toast.makeText(this, "Night mode selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.menuSystem) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                Toast.makeText(this, "System mode selected", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

    @Override
    public void onBackPressed() {
        int currentTab = viewPager2.getCurrentItem();
        if (currentTab != 0) {
            // Navigate back to the First tab
            viewPager2.setCurrentItem(0, true);
        } else {
            // On First tab → go back to MainActivity
            super.onBackPressed();
        }
    }

    // Handle the Up button (ancestral navigation) in the ActionBar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Navigate up to MainActivity directly
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
