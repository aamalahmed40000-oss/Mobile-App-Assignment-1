package com.example.amalaldarawsha;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class TabPagerAdapter extends FragmentStateAdapter {

    public TabPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: return TabFragment.newInstance("First",  "#4CAF50");
            case 1: return TabFragment.newInstance("Second", "#2196F3");
            case 2: return TabFragment.newInstance("Third",  "#FF5722");
            default: return TabFragment.newInstance("First", "#4CAF50");
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
