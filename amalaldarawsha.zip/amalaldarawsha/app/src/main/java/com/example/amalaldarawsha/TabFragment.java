package com.example.amalaldarawsha;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class TabFragment extends Fragment {

    private static final String ARG_LABEL = "label";
    private static final String ARG_COLOR = "color";

    public static TabFragment newInstance(String label, String color) {
        TabFragment fragment = new TabFragment();
        Bundle args = new Bundle();
        args.putString(ARG_LABEL, label);
        args.putString(ARG_COLOR, color);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_tab, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String label = getArguments() != null ? getArguments().getString(ARG_LABEL) : "Tab";
        String color = getArguments() != null ? getArguments().getString(ARG_COLOR) : "#000000";

        TextView tvTitle = view.findViewById(R.id.tvTabTitle);
        tvTitle.setText(label + " Fragment");

        // Tint the background accent card with a light version of the tab colour
        View accentBar = view.findViewById(R.id.accentBar);
        accentBar.setBackgroundColor(Color.parseColor(color));
    }
}
